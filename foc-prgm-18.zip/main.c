/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include<stdio.h>  
#include<conio.h>  
void main()  
{   
int num, rem, sum = 0, i;    
printf("Enter a number\n");  
scanf("%d", &num);  
while(num>0)
{
rem = num % 10;  
sum = sum + rem; 
num=num/10;
}
printf("the sum of digits %d",sum);
}