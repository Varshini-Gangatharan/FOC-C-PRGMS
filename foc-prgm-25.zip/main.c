/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int main()
{
    int a, b;
    printf("Enter the values of a and b: ");
    scanf("%d %d", &a, &b);
    if(a > b)
    {
        printf("%d is Largest\n", a);
    }
    else if (b > a)
    {
        printf("%d is Largest\n", b);
    }
    else
    {
        printf("Both are Equal\n");
    }
    return 0;
}