/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<stdio.h>
int main()
{
    int n, i;
    int sum = 0, avg, num;
    printf("Enter number of elements:  ");
    scanf("%d", &n);
    printf("\nEnter %d elements\n", n);
    for(i = 0; i < n; i++)
    {
        scanf("%d", &num);
        sum = sum + num;
    }
    avg = sum / n;
    printf("\nAverage of numbers is %d", avg);
    return 0;
}
