/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/
#include <stdio.h>
int main() 
{
    int i,n;
    int sum=0;
    printf("Enter the number: ");
    scanf("%d",&n);
    sum=(n*(n+1))/2;
    printf("Sum of the series: ");
    for(i=1;i<=n;i++)
    {
        if(i!=n)
        {
            printf("%d+",i);
        }
        else
        {
            printf("%d=%d",i,sum);
        }
    }
    return 0;
}

