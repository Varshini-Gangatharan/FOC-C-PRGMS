/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<stdio.h>
 
int main()
{
    int i, n;
    float x, sum=1, t=1;
     
    printf("Enter the value for x : ");
    scanf("%f", &x);
     
    printf("\nEnter the value for n : ");
    scanf("%d", &n);
    for(i=1;i<=n;i++)
    {
        t=t*x/i;
        sum=sum+t;
    }
     
    printf("\nThe Exponential Value of %f = %.4f", x, sum);
    return 0;
}

