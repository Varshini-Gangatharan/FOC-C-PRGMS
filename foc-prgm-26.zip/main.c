/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<stdio.h>
int  main()
{
    int i,n,a[10],lar;
    printf("Enter the number of elements:\n") ;
    scanf("%d",&n) ;
    printf("Enter the elements\n") ;
    for(i=0;i<n;i++)
    {
        scanf("%d",&a[i]) ;
    }
    lar=a[0];
    for(i=1;i<n;i++)
    {
        if(lar<a[i])
        {
            lar=a[i];
        }
    }
    printf("Largest of %d elements in an array = %d",n,lar);
}

 

