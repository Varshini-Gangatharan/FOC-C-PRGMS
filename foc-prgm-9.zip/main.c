/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int num,sum=0;
    printf("Enter  a positive number to sum series: ");
    scanf("%d",&num);
    sum=(num*(num+1)*(2*num+1))/6;
    printf("The sum of the series 1²+2²+3²+....+n² is %d",sum);
    return 0;
}
